/********************************************************************************
*  WEB322 – Assignment 06
* 
*  I declare that this assignment is my own work in accordance with Seneca's
*  Academic Integrity Policy:
* 
*  https://www.senecacollege.ca/about/policies/academic-integrity-policy.html
* 
*  Name: Tisha Patel Student ID: 140240235 Date: 30/11/2024
*   
********************************************************************************/

const express = require("express");
const path = require("path");
const session = require("express-session");
const countries = require("./modules/countryData");
const { regions, majorRegions } = require("./modules/subRegions");
const users = require("./modules/userData");

const app = express();

// Middleware setup
app.use(express.static(path.join(__dirname, "public")));
app.set("view engine", "ejs");
app.use(express.urlencoded({ extended: true }));

// Session setup
app.use(
  session({
    secret: "your-unique-secret-key",
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false },
  })
);

// Helper functions
function getFeaturedCountries(allCountries) {
  const featuredCountryIds = ["124", "840", "392"]; // Canada, USA, Japan
  return allCountries.filter((country) =>
    featuredCountryIds.includes(country.id)
  );
}

function getRegularCountries(allCountries) {
  const featuredCountryIds = ["124", "840", "392"];
  return allCountries.filter(
    (country) => !featuredCountryIds.includes(country.id)
  );
}

// Routes
app.get("/", (req, res) => {
  res.render("home", {
    countries: getFeaturedCountries(countries),
    regions: regions,
    session: req.session,
  });
});

app.get("/about", (req, res) => {
  res.render("about", {
    session: req.session,
  });
});

app.get("/countries", (req, res) => {
  res.render("countries", {
    countries: getRegularCountries(countries),
    regions: regions,
    majorRegions: majorRegions,
    session: req.session,
  });
});

// Authentication Routes
app.get("/login", (req, res) => {
  res.render("login", {
    session: req.session,
    errorMsg: null,
  });
});

app.post("/login", (req, res) => {
  const { userName, password } = req.body;
  const user = users.find(
    (u) => u.userName === userName && u.password === password
  );

  if (user) {
    req.session.user = user;
    res.redirect("/");
  } else {
    res.render("login", {
      session: req.session,
      errorMsg: "Invalid username or password",
    });
  }
});

app.get("/register", (req, res) => {
  res.render("register", {
    session: req.session,
    errorMsg: null,
  });
});

app.post("/register", (req, res) => {
  const { userName, password, password2 } = req.body;

  if (!userName || !password || !password2) {
    return res.render("register", {
      session: req.session,
      errorMsg: "All fields are required",
    });
  }

  if (password !== password2) {
    return res.render("register", {
      session: req.session,
      errorMsg: "Passwords do not match",
    });
  }

  if (users.some((u) => u.userName === userName)) {
    return res.render("register", {
      session: req.session,
      errorMsg: "Username already exists",
    });
  }

  users.push({ userName, password });
  res.redirect("/login");
});

app.get("/logout", (req, res) => {
  req.session.destroy();
  res.redirect("/");
});

// Error handling
app.use((req, res) => {
  res.status(404).render("404", {
    session: req.session,
  });
});

// Start server
const HTTP_PORT = process.env.PORT || 3000;
app.listen(HTTP_PORT, () => {
  console.log(`Server is running on port ${HTTP_PORT}`);
});
