 const mongoose = require("mongoose");

 let Country; // This will be our Country Model

 // Define the country schema
 const countrySchema = new mongoose.Schema({
   name: String,
   capital: String,
   population: Number,
   language: String,
   currency: String,
   continent: String,
 });

 function initialize() {
   return new Promise((resolve, reject) => {
     let db = mongoose.createConnection(process.env.MONGODB);

     db.on("error", (err) => {
       reject(err);
     });

     db.once("open", () => {
       Country = db.model("countries", countrySchema);
       resolve();
     });
   });
 }

 function getAllCountries() {
   return new Promise((resolve, reject) => {
     Country.find()
       .exec()
       .then((countries) => {
         if (countries.length === 0) {
           reject("No countries found");
         } else {
           resolve(countries);
         }
       })
       .catch((err) => {
         reject(err);
       });
   });
 }

 function getCountryById(id) {
   return new Promise((resolve, reject) => {
     Country.findById(id)
       .exec()
       .then((country) => {
         if (country) {
           resolve(country);
         } else {
           reject(`Country with ID: ${id} not found`);
         }
       })
       .catch((err) => {
         reject(err);
       });
   });
 }

 function addCountry(countryData) {
   return new Promise((resolve, reject) => {
     const newCountry = new Country(countryData);
     newCountry
       .save()
       .then(() => {
         resolve();
       })
       .catch((err) => {
         reject(err);
       });
   });
 }

 function updateCountry(countryData) {
   return new Promise((resolve, reject) => {
     Country.updateOne({ _id: countryData._id }, { $set: countryData })
       .exec()
       .then(() => {
         resolve();
       })
       .catch((err) => {
         reject(err);
       });
   });
 }

 function deleteCountry(id) {
   return new Promise((resolve, reject) => {
     Country.deleteOne({ _id: id })
       .exec()
       .then(() => {
         resolve();
       })
       .catch((err) => {
         reject(err);
       });
   });
 }

 module.exports = {
   initialize,
   getAllCountries,
   getCountryById,
   addCountry,
   updateCountry,
   deleteCountry,
 };